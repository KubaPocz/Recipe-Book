from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from datetime import date
from typing import List
import json
recipes_file_path = "Recipes.txt"
data = ""
class Ingredient:
    def __init__(self,name:str,unit:str,quantity:float):
        self.name = name
        self.unit = unit
        self.quantity = quantity
    def to_dict(self):
        return {
            "name": self.name,
            "unit": self.unit,
            "quantity": self.quantity
        }
    def from_dict(data: dict):
        return Ingredient(data["name"], data["unit"], data["quantity"])
class Recipe:
    def __init__(self,name:str,ingredients: List[Ingredient],steps: List[str],recipe_date=date.today()):
        self.name = name
        self.date = recipe_date
        self.ingredients = ingredients
        self.steps = steps
    def to_dict(self):
        return {
            "name": self.name,
            "date": self.date.isoformat(),
            "ingredients": [ingredient.to_dict() for ingredient in self.ingredients],
            "steps": self.steps
        }
    def from_dict(data: dict):
        ingredients = [Ingredient.from_dict(ing) for ing in data["ingredients"]]
        recipe_date = date.fromisoformat(data["date"])
        return Recipe(data["name"], ingredients, data["steps"], recipe_date)
def load_recipes_from_file():
    global data
    with open(recipes_file_path,"r") as file:
        data = json.load(file)
load_recipes_from_file()
recipes = [Recipe.from_dict(recipe_data) for recipe_data in data]
def delete_recipe_from_list():
    if len(recipes)>0:
        recipes.pop(recipes_list.curselection()[0])
    show_list()
def show_list():
    recipes_list.delete(0,END)
    if(len(recipes)>0):
        for i in range(len(recipes)):
            recipes_list.insert(i, recipes[i].name)
    else:
        recipes_list.insert(0,"Brak")
    recipes_list.select_set(0)
def show_recipe():
    if len(recipes)>0:
        current_recipe = recipes[recipes_list.curselection()[0]]
        recipe_window = Toplevel()
        recipe_window.title(f"{current_recipe.name} Recipe")
        recipe_window.minsize(400,100)
        recipe_window.columnconfigure(0, weight=1)
        recipe_window.columnconfigure(1, weight=1)
        recipe_window.columnconfigure(2, weight=1)
        Label(recipe_window,text=current_recipe.name, font=("Arial",30,"bold"),bg="darkgray").grid(row=0, column=0,columnspan=3,sticky="ew")
        Frame(recipe_window,height=2,bg="black").grid(row=1,column=0,columnspan=3,sticky="ew")
        Label(recipe_window,text="Ingredients",font=("Arial",18,"bold"), bg="lightgray").grid(row=2,column=0,columnspan=3,sticky="ew")
        for i in range(0,len(current_recipe.ingredients)):
            Label(recipe_window,text=current_recipe.ingredients[i].name,font=("Arial",12), bg="lightgray").grid(row=i+3,column=0,sticky="ew")
            Label(recipe_window,text=current_recipe.ingredients[i].quantity,font=("Arial",12), bg="lightgray").grid(row=i+3,column=1,sticky="ew")
            Label(recipe_window,text=current_recipe.ingredients[i].unit,font=("Arial",12), bg="lightgray").grid(row=i+3,column=2,sticky="ew")
        Frame(recipe_window,height=2,bg="black").grid(row=len(current_recipe.ingredients)+3,column=0,columnspan=3,sticky="ew")
        Label(recipe_window,text="Steps",font=("Arial",18,"bold"), bg="lightgray").grid(row=len(current_recipe.ingredients)+4,column=0,columnspan=3,sticky="ew")
        for i in range(0,len(current_recipe.steps)):
            Label(recipe_window,text=f"{i+1}. {current_recipe.steps[i]}",font=("Arial",12), bg="lightgray").grid(row=len(current_recipe.ingredients)+5+i,column=0,columnspan=3,sticky="we")
    else:
        messagebox.showerror("Error", "You have no recipes")
ing_row_number = 4
step_row_number = 4
ingredients =[]
ing_labels = []
steps_labels = []
def add_recipe():
    ing_windows = []
    add_recipe_window = Toplevel()
    add_recipe_window.title("Add Recipe")
    add_recipe_window.minsize(500,100)
    add_recipe_window.columnconfigure(0, weight=1,minsize=24)
    add_recipe_window.columnconfigure(1, weight=1,minsize=24)
    add_recipe_window.columnconfigure(2, weight=20,minsize=240)
    add_recipe_window.columnconfigure(3, weight=1,minsize=24)
    add_recipe_window.columnconfigure(4, weight=1,minsize=24)
    add_recipe_window.columnconfigure(5, weight=20,minsize=240)  
    def add_ingredient():
        add_ingredient_window = Toplevel()
        ing_windows.append(add_ingredient_window)
        add_ingredient_window.title("Add Ingredient")
        add_ingredient_window.minsize(300,100)
        add_ingredient_window.columnconfigure(0, weight=1)
        add_ingredient_window.columnconfigure(1, weight=1)
        add_ingredient_window.columnconfigure(2, weight=1)
        Label(add_ingredient_window,text="Add Ingredient", font=("Arial",30)).grid(row=0,column=0,columnspan=3,sticky="ew")
        Label(add_ingredient_window,text="Name", font=("Arial",18)).grid(row=1,column=0,sticky="ew")
        Label(add_ingredient_window,text="Quantity", font=("Arial",18)).grid(row=1,column=1,sticky="ew")
        Label(add_ingredient_window,text="Unit", font=("Arial",18)).grid(row=1,column=2,sticky="ew")
        ingredient_name = Entry(add_ingredient_window,font=("Arial",14))
        ingredient_name.grid(row=2,column=0,sticky="ew")
        def check_quantity():
            return quantity.get().isdigit()
        quantity = Spinbox(add_ingredient_window,font=("Arial",14),from_=0,to=100000,validate="key",validatecommand=check_quantity)
        quantity.grid(row=2,column=1,sticky="ew")
        unit = ttk.Combobox(add_ingredient_window,font=("Arial",14),values=["grams", "ml", "pieces","cups", "liters", "oz", "pounds", "tablespoons", "teaspoons"],state="readonly")
        unit.set("grams")
        unit.grid(row=2,column=2,sticky="ew")
        def save_ingredient():
            global ingredients
            if (quantity.get()).isdigit() and ingredient_name.get()!="" and quantity.get()!= 0:
                add_ingredient_label(ingredient_name.get(),quantity.get(),unit.get())
                ingredients.append(Ingredient(ingredient_name.get(),unit.get(),float(quantity.get())))
                add_ingredient_window.destroy() 
            elif ingredient_name.get()=="":
                messagebox.showerror("Error", "You have to set ingredient name")
            else:
                messagebox.showerror("Error", "You have incorrect format in quantity field")
        Button(add_ingredient_window,text="Save",command=save_ingredient, font=("Arial",18)).grid(row=3,column=0,columnspan=3,sticky="ew")
    def add_ingredient_label(name,quantity,unit):
        global ing_row_number,ing_labels
        ing_labels.append(Label(add_recipe_window,text=f"{ing_row_number-3}. {name}  -  {quantity} {unit}",font=("Arial",18)))
        ing_labels[ing_row_number-4].grid(row=ing_row_number,column=0,columnspan=3,sticky="w")
        ing_row_number += 1
    def delete_ingredient_label():
        global ing_row_number,ing_labels,ingredients
        if len(ing_labels)>0:
            ing_row_number -=1
            ing_labels[-1].destroy()
            ing_labels.pop()
            ingredients.pop()
    def add_step_label():
        global step_row_number,steps_labels
        steps_labels.append(Entry(add_recipe_window,font=("Arial",18),bd=2,relief="solid"))
        steps_labels[step_row_number-4].grid(row=step_row_number,column=3,columnspan=3,sticky="ew")
        step_row_number += 1
    def delete_step_label():
        global step_row_number,steps_labels
        if len(steps_labels)>0:
            step_row_number -=1
            steps_labels[-1].destroy()
            steps_labels.pop()
    def save_recipe():
        global ing_labels, steps_labels, recipes
        if recipe_name.get() == "":
            messagebox.showerror("Error", "You have empty name field")
            return
        if len(ingredients) == 0:
            messagebox.showerror("Error", "You have empty ingredients list")
            return
        for step in steps_labels:
            if (step.get()) =="":
                messagebox.showerror("Error", "You have empty step field")
                return
        if len(steps_labels)==0:
            messagebox.showerror("Error", "You have no step field")
            return        
        steps = [step.get() for step in steps_labels if step.get() != ""]
        recipes.append(Recipe(recipe_name.get(), ingredients, steps, recipe_date=date.today()))
        show_list()
        messagebox.showinfo("Success", "You added new recipe")
        add_recipe_window.destroy()
    def close_top_levels():
        if len(ing_windows) != 0:
            for ing_window in ing_windows:
                ing_window.destroy()
        add_recipe_window.destroy()
    Label(add_recipe_window,text="Add Recipe", font=("Arial",30),bg="darkgray").grid(row=0, column=0,columnspan=6, sticky="ew")
    Button(add_recipe_window,text="Save",command=save_recipe, font=("Arial",20),bg="white").grid(row=0, column=4,columnspan=2, sticky="e")
    Frame(add_recipe_window,height=2,bg="black").grid(row=1,column=0,columnspan=6,sticky="ew")
    Label(add_recipe_window,text="Name",font=("Arial",18)).grid(row=2,column=0,columnspan=3,sticky="w")
    recipe_name = Entry(add_recipe_window,font=("Arial",18),bd=2,relief="solid")
    recipe_name.grid(row=2,column=3,columnspan=3,sticky="ew")
    Button(add_recipe_window,text="+",command=add_ingredient,font=("Arial",10)).grid(row=3,column=0,sticky="ew")
    Button(add_recipe_window,text="-",command=delete_ingredient_label,font=("Arial",10)).grid(row=3,column=1,sticky="ew")    
    Label(add_recipe_window,text="Ingredients",font=("Arial",18)).grid(row=3,column=2,sticky="ew")
    Button(add_recipe_window,text="+",command=add_step_label,font=("Arial",10)).grid(row=3,column=3,sticky="ew")
    Button(add_recipe_window,text="-",command=delete_step_label,font=("Arial",10)).grid(row=3,column=4,sticky="ew")
    Label(add_recipe_window,text="Steps",font=("Arial",18)).grid(row=3,column=5,sticky="ew")
    add_recipe_window.protocol("WM_DELETE_WINDOW",close_top_levels) 
main_window = Tk()
main_window.title("Recipe Book")
main_window.minsize(400,100)
main_window.columnconfigure(0, weight=1)
main_window.columnconfigure(1, weight=1)
recipes_list = Listbox(main_window,font=("Arial",12), height=15)
recipes_list.grid(row=10,column=0,columnspan=2,rowspan=(len(recipes) if len(recipes)>0 else 1),sticky="ew")
Label(main_window,text="Recipe Book", font=("Arial",20)).grid(row=0, column=0,columnspan=2)
show_list()
Button(main_window,text="Delete",command=delete_recipe_from_list, font=("Arial",12)).grid(column=0,row=160,sticky="ew")
Button(main_window,text="Recipe",command=show_recipe, font=("Arial",12)).grid(column=1,row=160,sticky="ew")
Button(main_window,text="Add New Recipe", command=add_recipe,font=("Arial",12)).grid(column=0,row=161,columnspan=2,sticky="ew")
def save_recipes_to_file():
    with open(recipes_file_path,"w") as file:
        json.dump([recipe.to_dict() for recipe in recipes],file,indent=4)
    main_window.destroy()
main_window.protocol("WM_DELETE_WINDOW", save_recipes_to_file)
main_window.mainloop()
##To jest 200 linia kodu